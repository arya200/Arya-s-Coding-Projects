# ifndef FUNCTIONS_H
# define FUNCTIONS_H

int readPrefs (char fileName[], int ngames, int preferences[]);
int readPlan (char fileName[], int ngames, int plan[]);
int findBestVacation (int duration, int gamePreferences[], int ngames, int plan[]);

# endif