# include <iostream>
# include <fstream>
# include "functions.h"
# include "provided.h"

using std::cin;
using std::cout;
using std::endl;
using std::ifstream;

int main()
{
	int ngames, duration, preferences[200], plan[366];
	char titleName[20], gameTitles[MAX_NB_GAMES][MAX_TITLE_SIZE], prefName[20], planName[20];

	bool invalid  = false;
	cout << "Please enter ngames and duration: ";
	cin >> ngames >> duration;

	if ((ngames > 200) || (ngames <= 0) || (duration > 365) || (duration <= 0))
	{
		cout << "Invalid input." << endl;
		return -1;
	}

	cout << "Please enter name of file with titles: ";
	cin >> titleName;

	readGameTitles (titleName, ngames, gameTitles);

	cout << "Please enter name of file with preferences: ";
	cin >> prefName;

	if (readPrefs (prefName, ngames, preferences) == -1)
	{
		invalid = true;
	}

	cout << "Please enter name of file with plan: ";
	cin >> planName;

	if (readPlan(planName, ngames, plan) == -1)
	{
		cout << "Invalid file." << endl;
		invalid = true;
	}

	if (invalid)
		return -1;
	else
	{
		int start = findBestVacation (duration, preferences, ngames, plan);
		cout << "Best start day is " << start << endl;
		cout << "Games to be played: " << endl;
		printGamesPlayedInVacation (start, duration, plan, gameTitles, ngames);
	}

	cout << endl;

	return 0;
}