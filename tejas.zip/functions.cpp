#include <iostream>
#include <fstream>
#include "functions.h"

using std::cin;
using std::cout;
using std::endl;
using std::ifstream;
using std::string;
using std::isdigit;

int readPrefs(char fileName[], int ngames, int preferences[])
{
	int valid = 0, gameID, rating;
	ifstream inFS;
	inFS.open(fileName);
	
	if(!inFS.is_open())
		return -1;

	while (!inFS.eof())
	{
		inFS >> gameID;
		inFS >> rating;

		if ((rating >= 0 && rating <= 5) && (gameID >= 0 && gameID <= (ngames - 1)))
		{
			preferences[gameID] = rating;
			valid++;
		}
	}
	inFS.close();
	return valid;
}

int readPlan(char fileName[], int ngames, int plan[])
{
	int day, gameID;
	ifstream inFS;
	inFS.open(fileName);

	if(!inFS.is_open())
		return -1;

	while (!inFS.eof())
	{
		inFS >> day;
		inFS >> gameID;
		plan[day] = gameID;
	}
	return 0;
}

int computeFunLevel (int start, int duration, int gamePrefs[], int ngames, int plan[])
{
	int sum = 0, n;

	if((start + duration) > 366)
		return -1;

	for (int i = start; i < (start + duration); i++)
	{
		n = plan[i];
		sum += gamePrefs[n];
	}
	return sum;
}

int findBestVacation(int duration, int gamePrefs[], int ngames, int plan[])
{
	int max = -1, fun, date;

	for (int i = 1; i < (367 - duration); i++)
	{
		fun = computeFunLevel(i, duration, gamePrefs, ngames, plan);

		if (fun > max)
		{
			max = fun;
			date = i;
		}
	}
	return date;
}





