#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include <cmath>
#include "functions.h"

using namespace std;

Pixel** createImage(int width, int height) {
  cout << "Start createImage... " << endl;
  
  // Create a one dimensional array on the heap of pointers to Pixels 
  //    that has width elements (i.e. the number of columns)
  Pixel** image = new Pixel*[width];
  
  bool fail = false;
  
  for (int i=0; i < width; ++i) { // loop through each column
    // assign that column to a one dimensional array on the heap of Pixels
    //  that has height elements (i.e. the number of rows)
    image[i] = new Pixel[height];
    
    if (image[i] == nullptr) { // failed to allocate
      fail = true;
    }
  }
  
  if (fail) { // if any allocation fails, clean up and avoid memory leak
    // deallocate any arrays created in for loop
    for (int i=0; i < width; ++i) {
      delete [] image[i]; // deleting nullptr is not a problem
    }
    delete [] image; // dlete array of pointers
    return nullptr;
  }
  
  // initialize cells
  //cout << "Initializing cells..." << endl;
  for (int row=0; row<height; ++row) {
    for (int col=0; col<width; ++col) {
      //cout << "(" << col << ", " << row << ")" << endl;
      image[col][row] = { 0, 0, 0 };
    }
  }
  cout << "End createImage... " << endl;
  return image;
}

void deleteImage(Pixel** image, int width) {
  cout << "Start deleteImage..." << endl;
  // avoid memory leak by deleting the array
  for (int i=0; i<width; ++i) {
    delete [] image[i]; // delete each individual array placed on the heap
  }
  delete [] image;
  image = nullptr;
}

// implement for part 1

int* createSeam(int length) 
{

  int* seam = new int[length];

  for(int i=0;i<length;i++)
  {
    seam[i]=0;
  }


  return seam;
}

void deleteSeam(int* seam) 
{

  delete [] seam;

}

bool loadImage(string filename, Pixel** image, int width, int height)
{

  int colorvalue=0;
  ifstream ifs(filename);
  if(!ifs.is_open())
  {
    cout << "Error: failed to open input file - " << filename << endl;
    return false;

  }
  char type[3];
  ifs >> type;
  if ((toupper(type[0]) != 'P') || (type[1] != '3')) 
  {
    cout << "Error: type is " << type << " instead of P3" << endl;
    return false;
  }


  int w_check=0;
  int h_check=0;

  ifs >> w_check;

  if(ifs.fail())
  { 
    
    cout << "Error: read non-integer value" << endl;
    return false;

  }

  if(w_check!=width)
  {
    cout << "Error: input width ("<< width <<") does not match value in file ("<<w_check << ")" << endl;
    return false;
  }

  ifs >> h_check;

  if(ifs.fail())
  { 
    
    cout << "Error: read non-integer value" << endl;
    return false;

  }

  if(h_check!=height)
  {
    cout << "Error: input height ("<< height <<") does not match value in file ("<<h_check << ")" << endl;
    return false;
  }

  ifs >> colorvalue;
  if(ifs.fail())
  {
    cout << "Error: read non-integer value" << endl;
  }
  if((colorvalue>255)||(colorvalue<0))
  {
    cout << "Error: invalid color value " << colorvalue << endl;
  }

  for(int i = 0; i <height; i++)
{
  for(int j = 0; j <width; j++)
  {

    ifs >> image[j][i].r;

    if(ifs.fail())
    {
      if(ifs.eof())
      {
        cout << "Error: not enough color values" << endl;
        return false;
      }
    }

    if(ifs.fail())
    {

      cout << "Error: read non-integer value" << endl;
      return false;

    }

    if(image[j][i].r <0 || image[j][i].r >255)
    {

      cout << "Error: invalid color value " << image[j][i].r << endl;
      return false;

    } 

    ifs >> image[j][i].g;

    if(ifs.fail())
    {
      if(ifs.eof())
      {
        cout << "Error: not enough color values" << endl;
        return false;
      }
    }

    if(ifs.fail())
    {

      cout << "Error: read non-integer value" << endl;
      return false;

    }

    if(image[j][i].g <0 || image[j][i].g >255)
    {

      cout << "Error: invalid color value " << image[j][i].g << endl;
      return false;

    }

    ifs >> image[j][i].b;

    if(ifs.fail())
    {
      if(ifs.eof())
      {
        cout << "Error: not enough color values" << endl;
        return false;
      }
    }

    if(ifs.fail())
    {

      cout << "Error: read non-integer value" << endl;
      return false;

    }

    if(image[j][i].b <0 || image[j][i].b >255)
    {

      cout << "Error: invalid color value " << image[j][i].b << endl;
      return false;
    }
  }
}
  
  int value=0;
  
  if(ifs >> value)
  {
    cout << "Error: too many color values" << endl;
    return false;

  }

  return true;
}





bool outputImage(string filename, Pixel** image, int width, int height) 
{

  fstream ifs(filename);
  if(!ifs.is_open())
  {
    cout << "failed to open output file " << filename << endl;
    return false;
  }

  ifs << "P3" << endl;
  ifs << width << " " << height << endl;
  ifs << 255 << endl;

  for(int i = 0; i <height; i++)
  {
    for(int j = 0; j <width; j++)
    {
        ifs << image[j][i].r << " " << image[j][i].g << " " << image[j][i].b << endl;
    }
  }

  return true;
}

int energy(Pixel** image, int x, int y, int width, int height) 
{ 
  int delta_rx = 0;
  int delta_gx=0;
  int delta_bx=0;
  int totalx = 0;
  int delta_ry = 0;
  int delta_gy=0;
  int delta_by = 0;
  int totaly = 0;
  int energy=0;

  if(x==0)
  {

    delta_rx = image[x+1][y].r - image[width-1][y].r;
    delta_gx = image[x+1][y].g - image[width-1][y].g;
    delta_bx = image[x+1][y].b - image[width-1][y].b;

  }
  else if(x == width -1)
  {

    delta_rx = image[0][y].r - image[x-1][y].r;
    delta_gx = image[0][y].g - image[x-1][y].g;
    delta_bx = image[0][y].b - image[x-1][y].b;

  }
  else
  {

    delta_rx = image[x+1][y].r - image[x-1][y].r;
    delta_gx = image[x+1][y].g - image[x-1][y].g;
    delta_bx = image[x+1][y].b - image[x-1][y].b;

  }

  totalx = (delta_rx*delta_rx) + (delta_gx*delta_gx) + (delta_bx*delta_bx);

  if(y==0)
  {

    delta_ry = image[x][y+1].r - image[x][height - 1].r;
    delta_gy = image[x][y+1].g - image[x][height - 1].g;
    delta_by = image[x][y+1].b - image[x][height - 1].b; 

  }
  else if(y == height-1)
  {

    delta_ry = image[x][0].r - image[x][y-1].r;
    delta_gy = image[x][0].g - image[x][y-1].g;
    delta_by = image[x][0].b - image[x][y-1].b; 

  }
  else
  {

    delta_ry = image[x][y+1].r - image[x][y-1].r;
    delta_gy = image[x][y+1].g - image[x][y-1].g;
    delta_by = image[x][y+1].b - image[x][y-1].b; 

  } 

  totaly = (delta_ry*delta_ry) + (delta_gy*delta_gy) + (delta_by*delta_by);

  energy = totalx + totaly; 

  return energy;

}
 

// int loadVerticalSeam(Pixel** image, int start_col, int width, int height, int* seam) 
// {






//   return 0;
// }

// int loadHorizontalSeam(Pixel** image, int start_row, int width, int height, int* seam) {
//   return 0;
// }

// int* findMinVerticalSeam(Pixel** image, int width, int height) {
//   return nullptr;
// }

// int* findMinHorizontalSeam(Pixel** image, int width, int height) {
//   return nullptr;
// }

// void removeVerticalSeam(Pixel** image, int width, int height, int* verticalSeam) {
// }


// void removeHorizontalSeam(Pixel** image, int width, int height, int* horizontalSeam) {
// }
