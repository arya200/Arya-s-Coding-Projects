#include <iostream>
#include "Vect.h"

using namespace std;

int main()
{


	return 0;
}